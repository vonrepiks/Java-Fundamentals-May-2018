package vehicles_extension;

public class Bus extends Vehicle {
    public Bus(double fuelQuantity, double fuelConsumptionPerKilometer, double tankCapacity) {
        super(fuelQuantity, fuelConsumptionPerKilometer, tankCapacity);
    }
//
//    @Override
//    protected void setFuelConsumptionPerKilometer(double fuelConsumptionPerKilometer) {
//        super.setFuelConsumptionPerKilometer(fuelConsumptionPerKilometer + SUMMER_MODE_PERMANENT_ON);
//    }
}
