package telephony;

public interface Browsable {

    String browse(String email);
}
