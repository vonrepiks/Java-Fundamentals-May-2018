package border_control;

public interface Identifable {

    String getId();
}
